{
	"ModelAdmin.SAVED": "Zapisano",
	"ModelAdmin.REALLYDELETE": "Napewno usunąć?",
	"ModelAdmin.DELETED": "Usunięto",
	"LeftAndMain.PAGEWASDELETED": "Ta strona została usunięta."
}