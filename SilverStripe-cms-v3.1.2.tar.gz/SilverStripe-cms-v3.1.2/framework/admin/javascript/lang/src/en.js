{
	"LeftAndMain.CONFIRMUNSAVED": "Are you sure you want to navigate away from this page?\n\nWARNING: Your changes have not been saved.\n\nPress OK to continue, or Cancel to stay on the current page.",
	"LeftAndMain.CONFIRMUNSAVEDSHORT": "WARNING: Your changes have not been saved.",
	"SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Do you really want to delete %s groups?",
	"ModelAdmin.SAVED": "Saved",
	"ModelAdmin.REALLYDELETE": "Do you really want to delete?",
	"ModelAdmin.DELETED": "Deleted",
	"ModelAdmin.VALIDATIONERROR": "Validation Error",
	"LeftAndMain.PAGEWASDELETED": "This page was deleted.  To edit a page, select it from the left."
}
