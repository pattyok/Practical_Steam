{
	"ModelAdmin.SAVED": "Uloženo",
	"ModelAdmin.REALLYDELETE": "Skutečně chcete smazat?",
	"ModelAdmin.DELETED": "Smazáno",
	"LeftAndMain.PAGEWASDELETED": "Tato stránka byla smazána. Pro editaci stránky, vyberte ji vlevo.",
	"LeftAndMain.CONFIRMUNSAVED": "Určitě chcete opustit navigaci z této stránky?\n\nUPOZORNĚNÍ: Vaše změny nebyly uloženy.\n\nStlačte OK pro pokračovat, nebo Cancel, zůstanete na této stránce."
}