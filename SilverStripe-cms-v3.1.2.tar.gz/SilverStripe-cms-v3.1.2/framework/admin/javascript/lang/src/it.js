{
	"ModelAdmin.SAVED": "Salvato",
	"ModelAdmin.REALLYDELETE": "Si è sicuri di voler eliminare?",
	"ModelAdmin.DELETED": "Eliminato",
	"LeftAndMain.PAGEWASDELETED": "Questa pagina è stata eliminata. Per modificare questa pagine, selezionarla a sinistra.",
	"LeftAndMain.CONFIRMUNSAVED": "Siete sicuri di voler uscire da questa pagina?\n\nATTENZIONE: I vostri cambiamenti non sono stati salvati.\n\nCliccare OK per continuare, o su Annulla per rimanere sulla pagina corrente."
}